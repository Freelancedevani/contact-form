const userName = document.querySelector('.userName');
const userEmail = document.querySelector('.userEmail');
const userSubject = document.querySelector('.useSubject');
const userMessage = document.querySelector('.userMessage');
const messageDisplay = document.querySelector('.messageDisplay');
const submitter = document.querySelector('.submitter');




// send data to the server
function sendToServer(username, email, subject, message){
const data = {name: username, email: email, subject: subject , message: message};
axios.post('contact.php', data).then(response=>{
    messageDisplay.innerHTML = response.data;

    messageDisplay.classList.add('success');
    userName.value = '';
    userEmail.value = '';
    userSubject.value = '';
    userMessage.value = '';
    setTimeout(()=>{
        messageDisplay.innerHTML = '';
        messageDisplay.classList.remove('success');
    }, 3000);
})
}




// validate the Name and Email and Subject fields

const textRegex = /[^a-zA-Z0-9]/;
const emailRegex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;



// validate

function validate( username, email, subject, message){
 if(!username || !email || !subject || !message){
    addError('Please enter a username & email !');
    return false;
 }

 if(textRegex.test(username)){
    addError('Please enter a valid Name !');
    return false;
 }

 if(!email.match(emailRegex)){
    addError('Please enter a valid email !');
    return false;
 }

 if(textRegex.test(subject)){
    addError('Please enter a valid subject !');
    return false;
 }
 
sendToServer(username, email, subject, message);

}

// add error class
function addError( text){
    messageDisplay.innerHTML = text;
    messageDisplay.classList.add('error');

    setTimeout(()=>{
        messageDisplay.innerHTML = '';
        messageDisplay.classList.remove('error');
    },3000)
}




// triger 

submitter.addEventListener('click',()=>{
    const username = userName.value.trim().toLowerCase();
    const email = userEmail.value.trim().toLowerCase();
    const subject = userSubject.value.trim().toLowerCase();
    const message = userMessage.value.trim().toLowerCase();

     validate(username, email, subject, message);

})


