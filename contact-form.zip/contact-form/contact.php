<?php
$data = json_decode(file_get_contents("php://input"), TRUE);

$name = $data['name'];
$email = $data['email'];
$subjected = $data['subject'];
$message = $data['message'];
$subject = "Form submission";

// API endpoint and key
$endpoint = 'https://api.brevo.com/v3/smtp/email';
$api_key = '';

// Request payload
$datas = [
    'sender' => [
        'name' => $name,
        'email' => $email
    ],
    'to' => [
        [
            'email' => 'example@gmail.com',  // change with your email address
            'name' => 'Company Name',
        ]
    ],
    'subject' => $subject,
    'htmlContent' => '<table align="center" border="0" cellpadding="0" cellspacing="20" height="100%" width="100%">
    <tr>
        <td align="center" valign="top">
            <table width="600" bgcolor="#f8f6fe" cellpadding="7"
                style="font-size:16px; padding:30px; line-height: 28px;">
                <tr>
                    <td style="text-align:right; padding-right: 20px;" width="100" valign="top"><strong>Name:</strong></td>
                    <td>'.$name.'</td>
                </tr>
                <tr>
                    <td style="text-align:right; padding-right: 20px;" width="100" valign="top"><strong>Email:</strong></td>
                    <td>'.$email.'</td>
                </tr>
                <tr>
                    <td style="text-align:right; padding-right: 20px;" width="100" valign="top"><strong>Subject:</strong></td>
                    <td>'.$subjected.'</td>
                </tr>
                <tr>
                    <td style="text-align:right; padding-right: 20px;" width="100" valign="top"><strong>Message:</strong>
                    </td>
                    <td>'.$message.'</td>
                </tr>
            </table>
        </td>
    </tr>
</table>'
];

// Set cURL options
$options = [
    CURLOPT_URL => $endpoint,
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode($datas),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'accept: application/json',
        'api-key: ' . $api_key,
        'content-type: application/json'
    ]
];

// echo "<pre>";
// print_r($data);
// echo "</pre>";

// Initialize cURL session
$curl = curl_init();

// Set cURL options
curl_setopt_array($curl, $options);

// Execute the request
$response = curl_exec($curl);

// Check for errors
if ($response === false) {
    echo 'cURL error: ' . curl_error($curl);
    // Handle the error accordingly
} else {
    // Decode the JSON response
    $response_data = json_decode($response, true);

    // Check if JSON decoding was successful
    if ($response_data === null) {
        echo 'JSON decoding error.';
    } else {
        // Check if response contains 'messageId' key
        if (isset($response_data['messageId'])) {
            echo 'Email sent successfully!';
        } elseif (isset($response_data['error'])) {
            // Check if response contains 'error' key
            echo 'Email sending failed. Error: ' . $response_data['error'];
        } else {
            // Print response for debugging purposes
            echo 'Unknown error occurred. Response: ' . print_r($response_data, true);
        }
    }
}


// Close cURL session
curl_close($curl);
?>